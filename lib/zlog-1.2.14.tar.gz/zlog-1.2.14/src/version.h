#define ZLOG_VERSION "1.2.12"
